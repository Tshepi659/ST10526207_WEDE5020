// Wait until the page structure is loaded before adding interactive behaviour.
document.addEventListener('DOMContentLoaded', () => {
  // Mobile navigation: toggle the menu when the Menu button is clicked.
  const menu = document.querySelector('.menu-btn');
  const links = document.querySelector('.navlinks');

  if (menu && links) {
    menu.addEventListener('click', () => {
      links.classList.toggle('open');
    });
  }

  // Demonstration forms: prevent a page refresh and display confirmation feedback.
  document.querySelectorAll('form[data-demo]').forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();

      const flash = form.parentElement.querySelector('.flash');
      if (flash) {
        flash.style.display = 'block';
        flash.textContent = 'Thank you. Your submission has been recorded for this website demonstration.';
        form.reset();
      }
    });
  });
});
