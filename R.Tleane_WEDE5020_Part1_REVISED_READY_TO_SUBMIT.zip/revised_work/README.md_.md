## Reitumetse Tleane
## ST10526207
# iMentorU Foundation 
##WEDE5020W Part 1

## Project contents
- index.html — Home
- about.html — About Us
- programmes.html — Programmes
- volunteer.html — Get Involved
- contact.html — Contact
- css/style.css — Responsive styling
- js/main.js — Navigation and demonstration-form behaviour
- images/ — Local SVG branding/illustration assets
- research/ — Research evidence and source list
- docs/ — Proposal and project documentation

## How to run
Open `index.html` in a modern web browser. No server or database is required.

## Features
- Responsive five-page website
- Consistent navigation and footer
- Accessible labels and alt text
- Programme cards and calls to action
- Volunteer and contact forms with front-end validation/demo feedback
- Mobile navigation
- Local assets so the project can run offline

## Part 1 / POE alignment
The original guide requires a proposal, research evidence, five HTML pages, and organised project folders. This final project includes all of these elements and extends the basic HTML foundation with styling and simple JavaScript.

## Branding
The website uses the iMentorU Foundation organisation logo supplied for this project as `images/imentoru-foundation-official-logo.png`.
