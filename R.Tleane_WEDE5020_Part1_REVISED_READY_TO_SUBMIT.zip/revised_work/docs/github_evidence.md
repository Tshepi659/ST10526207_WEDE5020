# GitHub / Version-Control Evidence

## Repository status
This project has been prepared as a Git repository and contains a development history for the revised submission.

## Local commit history
- `e12dfb1` — Initial iMentorU Foundation website project
- `0690705` — Add revised proposal and submission documentation

## Required final GitHub step
1. Create a GitHub repository using the student's own GitHub account.
2. Name the repository, for example: `iMentorU-Foundation-WEDE5020`.
3. Add the remote URL supplied by GitHub:
   `git remote add origin YOUR-GITHUB-REPOSITORY-URL`
4. Push the branch:
   `git branch -M main`
   `git push -u origin main`
5. Open the repository in a browser and capture the repository page and commit-history page if the assessment requires screenshots.
6. Submit the actual GitHub repository URL through the lecturer's assessment link.

The placeholder `YOUR-GITHUB-REPOSITORY-URL` is intentionally not replaced with an invented URL. The student's real repository URL should be used after the repository is created.
