# iMentorU Foundation Website — WEDE5020W Part 1

**Student:** Reitumetse Tleane  
**Student Number:** ST10526207

## Project overview
This is an academic website project for the iMentorU Foundation. The project presents organisational information, programmes, volunteer opportunities and contact information through a responsive five-page interface.

## Pages
- `index.html` — Home
- `about.html` — About Us
- `programmes.html` — Programmes
- `volunteer.html` — Get Involved
- `contact.html` — Contact

## Project folders
- `css/` — Responsive stylesheet
- `js/` — JavaScript interactions and demonstration-form behaviour
- `images/` — Local logo and illustration assets
- `research/` — Research notes and source evidence
- `docs/` — Revised proposal, site map, wireframes and GitHub evidence

## How to run
Open `index.html` in a modern web browser such as Chrome, Edge or Firefox. No server or database is required for the academic demonstration.

## Features
- Responsive five-page website
- Consistent navigation and footer
- Accessible labels and image alternative text
- Programme cards and calls to action
- Volunteer and contact forms with front-end validation
- Mobile navigation
- Local assets for offline demonstration
- Documented CSS and JavaScript comments
- Wireframes and revised proposal documentation

## Forms
The volunteer and contact forms are demonstration forms. They validate required fields in the browser and display confirmation feedback, but they do not send real applications or messages to the organisation.

## Revised Part 1 evidence
The `docs/` folder includes:
- `R.Tleane_WEDE5020_Part1_REVISED.docx` — revised proposal
- `wireframes/wireframes.svg` — low-fidelity wireframes
- `github_evidence.md` — version-control/GitHub submission instructions
- `site_map.txt` — site structure

## GitHub
This project is Git-ready. Before final submission, create the student's GitHub repository, push the project, and submit the actual repository URL required by the assessment.

## References
Research sources are documented in `research/research_notes.md` and the revised proposal.
