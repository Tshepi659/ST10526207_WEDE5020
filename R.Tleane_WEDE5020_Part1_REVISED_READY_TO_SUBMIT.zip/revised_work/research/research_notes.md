# iMentorU Foundation — Research Evidence

## Organisation
iMentorU Foundation is a South African youth development and mentorship non-profit organisation.

## Key facts used in the website
- Established in September 2017 by Mr Tinyiko Miracle Mabale.
- Officially registered in 2019.
- Target group: young people approximately 8–35 years old.
- Mission centres on empowering, mentoring and supporting children, youth and communities through mentorship, skills development and education.
- Programme pillars include Educational Support; Career Mentorship & Training; STEAM Education; Language Learning; Community & Social Development; and Sports, Recreation, Arts & Culture.
- Public contact information lists the Pretoria head office, phone numbers and email.
- Public information lists short programmes including Digital Literacy & Web Design and Business English.

## Sources
1. iMentorU Foundation — Home: https://www.imentorufoundation.org.za/
2. iMentorU Foundation — Our Profile: https://www.imentorufoundation.org.za/our-profile
3. iMentorU Foundation — Our History: https://www.imentorufoundation.org.za/our-history
4. iMentorU Foundation — Programmes: https://www.imentorufoundation.org.za/
5. iMentorU Foundation — Volunteer: https://www.imentorufoundation.org.za/volunteer
6. iMentorU Foundation — Contact: https://www.imentorufoundation.org.za/contact-us
7. iMentorU Foundation — Support: https://www.imentorufoundation.org.za/support

## Academic-project note
The website content is based on publicly available information and is presented as an academic web-development project. Application/contact forms are demonstration forms and do not submit information to the organisation.
